#' Crossover [O(1)]
#'
#' Returns a boolean vector with True cells where the value of serie croses over the treshhold value.
#' Complexity order: O(1)
#' @param serie a numerical vector
#' @param value a treshhold value as a vector or number
#' @return a boolean vector
#' @seealso
#' \link{Neb.Previous}
#' @export

Neb.Crossover <- function(serie, value)
{
  res   <- as.logical(matrix(nrow = length(serie), ncol = 1, F))
  if (length(value) == 1)
    res[Neb.Previous(serie, 1) <= value & serie > value] <- T
  else
    res[Neb.Previous(serie, 1) <= Neb.Previous(value, 1) & serie > value] <- T
  return(res)
}
