#' Exponential Moving Average [O(n)]
#'
#' Calculates Exponential Moving Avrage of a serie with the givven length.
#' Complexity order: O(length(serie))
#' @param serie a numerical serie
#' @param length [1, +inf]eN an intger number
#' @return an exponential moving average as vector
#' @export

Neb.EMA <- function(serie, length)
{
  M <- 2 / (length + 1)
  EMA <- matrix(NA, ncol = length(serie), nrow = 1)
  EMA[length] <- sum(serie[1:length])/length
  for (i in (length+1):length(serie)) {
    EMA[i] <- (serie[i] - EMA[i-1]) * M + EMA[i-1]
  }
  return(as.numeric(EMA))
}


