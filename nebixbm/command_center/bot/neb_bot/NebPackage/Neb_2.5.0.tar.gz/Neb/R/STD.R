#' Strategy Tester for Derivative Markets[O(-) or O(-)]
#'
#' This function calculates some necessary metrics to evaluate trading system.
#' Complexity order: O(-) or O(-) for detailed
#' @param dataset data frame containing following variables:
#' dataset$LongEntry as boolean
#' dataset$LongExit as boolean
#' dataset$ShortEntry as boolean
#' dataset$ShortExit as boolean
#' dataset$PSM as a multiplier of equity
#' @param initialCapital in terms of base currency
#' @param commision in terms of percent
#' @param detailed calculation to generate detailed results
#' @param datasetName the name of dataset
#' @param pairName the name of the pair
#' @param liquiditySlippage the slippage of opening position in percent
#' @export

Neb.STD <-
  function(dataset,
           initialCapital,
           commision,
           detailed = F,
           datasetName = NA,
           pairName = NA,
           liquiditySlippage = 0.05) {
    # Check if data contains necessary properties
    if (is.null(dataset$LongEntry) | is.null(dataset$LongExit) |
        is.null(dataset$ShortEntry) | is.null(dataset$ShortExit)) {
      return(warning("STD input error. One or more input signls missing."))
    }
    if (is.null(dataset$Index))
      dataset$Index <- 1:dim(dataset)[1]

    # Remove NA from signals
    dataset$LongEntry[is.na(dataset$LongEntry)]   <- F
    dataset$LongExit[is.na(dataset$LongExit)]     <- F
    dataset$ShortEntry[is.na(dataset$ShortEntry)] <- F
    dataset$ShortExit[is.na(dataset$ShortExit)]   <- F

    # Indicate signal indexes
    Signals <-
      dataset$Index[dataset$LongExit |
                      dataset$ShortExit | dataset$LongEntry | dataset$ShortEntry]

    # Check the last signal on last data point
    if (length(Signals) != 0)
      if (Signals[length(Signals)] == dim(dataset)[1])
        Signals <- Signals[1:(length(Signals) - 1)]

    # Check if all PSM values are given for signals
    if (NA %in% dataset$PSM[dataset$LongEntry | dataset$ShortEntry]) {
      stop(
        "STD input values error. One or more $LongEnty or $ShortEntry signals dont have PSM value."
      )
      return(NULL)
    }

    # Check if all SL values are given for signals
    if (NA %in% dataset$SL[dataset$LongEntry | dataset$ShortEntry]) {
      stop(
        "STD input values error. One or more $LongEnty or $ShortEntry signals dont have SL value."
      )
      return(NULL)
    }

    # Check if Long and Short entry signals co-exists in the same bar
    if (max(dataset$LongEntry + dataset$ShortEntry) > 1)
      stop(
        "STD input value warning. One or more $LongEntry and $ShortEntry signals co-exists in the same bar."
      )

    # Initialization of req. variables

    List.Side       <- NULL
    List.SL.doHit   <- NULL
    List.EntryPrice <- NULL
    List.ExitPrice  <- NULL
    List.EntryIndex <- NULL
    List.ExitIndex  <- NULL
    inTrade         <- F
    side            <- NULL
    SL              <- NULL


    # Signal processing
    for (s in Signals) {
      if (inTrade) {
        # Close the position when hit stoploss
        if (side == "Long" &
            min(dataset$Low[List.EntryIndex[length(List.EntryIndex)]:s]) <= SL) {
          List.SL.doHit <- c(List.SL.doHit, T)

          x <- dataset$Low[List.EntryIndex[length(List.EntryIndex)]:s]
          i <-
            dataset$Index[List.EntryIndex[length(List.EntryIndex)]:s]

          List.ExitIndex <- c(List.ExitIndex, (i[x <= SL])[1])
          List.ExitPrice <- c(List.ExitPrice, SL)

          inTrade  <- F
          side     <- NULL
          SL       <- NULL
        }
        else if (side == "Short" &
                 max(dataset$High[List.EntryIndex[length(List.EntryIndex)]:s]) >= SL) {
          List.SL.doHit <- c(List.SL.doHit, T)

          x <-
            dataset$High[List.EntryIndex[length(List.EntryIndex)]:s]
          i <-
            dataset$Index[List.EntryIndex[length(List.EntryIndex)]:s]

          List.ExitIndex <- c(List.ExitIndex, (i[x >= SL])[1])
          List.ExitPrice <- c(List.ExitPrice, SL)

          inTrade  <- F
          side     <- NULL
          SL       <- NULL
        }

        # Close the position on next bar's open when close by exit signal
        else if ((dataset$LongExit[s] |
                  dataset$ShortEntry[s]) & side == "Long") {
          # Close the Long position on next bars open
          List.SL.doHit  <- c(List.SL.doHit, F)
          inTrade        <- F
          side           <- NULL
          List.ExitIndex <- c(List.ExitIndex, s + 1)
          List.ExitPrice <- c(List.ExitPrice, dataset$Open[s + 1])
        }
        else if ((dataset$ShortExit[s] |
                  dataset$LongEntry[s]) & side == "Short") {
          # Close the Short position on next bar's open
          List.SL.doHit  <- c(List.SL.doHit, F)
          inTrade        <- F
          side           <- NULL
          List.ExitIndex <- c(List.ExitIndex, s + 1)
          List.ExitPrice <- c(List.ExitPrice, dataset$Open[s + 1])
        }
      }
      if (inTrade == F) {
        # Open a position
        if (dataset$LongEntry[s]) {
          if (dataset$LongExit[s] != T) {
            # Open a Long position on next bar's open
            inTrade   <- T
            side      <- "Long"
            List.Side <- c(List.Side, side)
            List.EntryIndex <- c(List.EntryIndex, s + 1)
            List.EntryPrice <- c(List.EntryPrice, dataset$Open[s + 1])
            SL <- dataset$SL[s]
          }
        }
        else if (dataset$ShortEntry[s]) {
          if (dataset$ShortExit[s] != T) {
            # Open a Short position on next bar's open
            inTrade   <- T
            side      <- "Short"
            List.Side <- c(List.Side, side)
            List.EntryIndex <- c(List.EntryIndex, s + 1)
            List.EntryPrice <- c(List.EntryPrice, dataset$Open[s + 1])
            SL <- dataset$SL[s]
          }
        }
      }
    }

    # Check if all positions are closed
    if (!is.null(List.EntryIndex)) {
      if (length(List.EntryIndex) != length(List.ExitIndex)) {
        if (length(List.EntryIndex) == 1) {
          # --Only one Entry with no exit
          List.Side <- NULL
          List.EntryIndex <- NULL
          List.EntryPrice <- NULL
          # warning("STD warning. Single entry without exit.")
        }
        else{
          # --Only the last Entry has no exit
          List.Side       <- List.Side[1:(length(List.Side) - 1)]
          List.EntryIndex <-
            List.EntryIndex[1:(length(List.EntryIndex) - 1)]
          List.EntryPrice <-
            List.EntryPrice[1:(length(List.EntryPrice) - 1)]
          # warning("STD warning. Last entry has no exit. Last open position will be ignored.")
        }
      }
    }

    # Safty function
    if (length(List.Side) < 2) {
      return(NA)
    }

    # Calculations

    # Apply liquidity slippage
    List.EntryPrice[List.Side == "Long"] <-
      List.EntryPrice[List.Side == "Long"] +
      ((List.EntryPrice[List.Side == "Long"] * liquiditySlippage) / 100)
    List.EntryPrice[List.Side == "Short"] <-
      List.EntryPrice[List.Side == "Short"] -
      ((List.EntryPrice[List.Side == "Short"] * liquiditySlippage) / 100)
    List.ExitPrice[List.Side == "Long"] <-
      List.ExitPrice[List.Side == "Long"] -
      (( List.ExitPrice[List.Side == "Long"] * liquiditySlippage) / 100)
    List.ExitPrice[List.Side == "Short"] <-
      List.ExitPrice[List.Side == "Short"] +
      (( List.ExitPrice[List.Side == "Short"] * liquiditySlippage) / 100)

    # Assinment of PSM
    List.PSM <- dataset$PSM[List.EntryIndex - 1]

    # Calculate numberOfTrades
    numberOfTrades <- length(List.Side)

    # Calculate numberOfLongs
    numberOfLongs  <- length(List.Side[List.Side == "Long"])

    # Calculate numberOfShorts
    numberOfShorts <- length(List.Side[List.Side == "Short"])



    # Calculate pnlp for short trades
    pnlp          <-
      as.numeric(matrix(NA, nrow = numberOfTrades, ncol = 1))
    tradeIsShort  <- List.Side == "Short"
    pnlp[tradeIsShort] <-
      ((List.EntryPrice[tradeIsShort] - List.ExitPrice[tradeIsShort]) /
        List.EntryPrice[tradeIsShort]) * 100 -
      commision * 2

    # Calculate pnlp for long trades
    tradeIsLong  <- List.Side == "Long"
    pnlp[tradeIsLong] <-
      ((List.ExitPrice[tradeIsLong] - List.EntryPrice[tradeIsLong]) /
         List.EntryPrice[tradeIsLong]) * 100 -
      commision * 2

    # Apply Position Size
    pnlp <- pnlp * List.PSM

    # Calculate winOrLoss
    winOrLoss <-
      as.character(matrix(NA, nrow = numberOfTrades, ncol = 1))
    winOrLoss[pnlp > 0]  <- "Win"
    winOrLoss[pnlp <= 0] <- "Loss"

    # Calculate equityPerTrade and pnl for first trade
    equityPerTrade    <-
      as.numeric(matrix(NA, nrow = numberOfTrades, ncol = 1))
    pnl               <-
      as.numeric(matrix(NA, nrow = numberOfTrades, ncol = 1))
    equityPerTrade[1] <-
      (initialCapital * (pnlp[1] / 100)) + initialCapital
    pnl[1]            <- (initialCapital * (pnlp[1] / 100))

    # Calculate capital and pnl for other trade
    if (numberOfTrades > 1) {
      for (trade in 2:numberOfTrades) {
        equityPerTrade[trade] = (abs(equityPerTrade[trade - 1]) * (pnlp[trade] / 100)) + equityPerTrade[trade - 1]
        pnl[trade] = equityPerTrade[trade] - equityPerTrade[trade - 1]
      }
    }

    # Calculate netPNLP
    netPNLP <-
      (equityPerTrade[length(equityPerTrade)] - initialCapital) / initialCapital * 100

    # Calculate netPNL
    netPNL <-
      (equityPerTrade[length(equityPerTrade)] - initialCapital)

    # Calculate number of wining trades
    wins    <- length(winOrLoss[winOrLoss == "Win"])

    # Calculate number of losing trades
    losses  <- length(winOrLoss[winOrLoss == "Loss"])

    # Calculate win rate
    winRate <- wins / (numberOfTrades) * 100

    # Calcualte maxProfit
    maxProfit <- max(pnlp)

    # Calcualte maxLoss
    maxLoss   <- -min(pnlp)

    # Calculate grossProfit
    grossProfit <- sum(pnl[pnl > 0])

    # Calculate grossLoss
    grossLoss   <- -sum(pnl[pnl < 0])

    # Calculate profitFactor
    profitFactor <- grossProfit / grossLoss

    # Calculate buyAndHold
    buyAndHold   <-
      ((List.ExitPrice[length(List.ExitPrice)] - List.EntryPrice[1]) / List.EntryPrice[1]) * 100

    # Calculate Balance
    balance  <-
      as.numeric(matrix(NA, nrow = dim(dataset)[1], ncol = 1))
    balance[List.ExitIndex] <- equityPerTrade
    balance <- na.locf(balance, na.rm = F)
    dates   <- as.POSIXlt(dataset$Date, format = "%y/%m/%d - %H:%M")
    mons    <- as.numeric(dates$mon)

    # Calculate sharpeRatio (Left for future!)
    # Equity On Month Begining
    EOMB <- balance[Neb.Derivate(mons) != 0]
    eachMonthReturn  <- (Neb.Derivate(EOMB) / Neb.Previous(EOMB, 1)) * 100
    averageMonthlyReturn = mean(eachMonthReturn, na.rm = T)
    sharpeRatio = (averageMonthlyReturn) / sd(eachMonthReturn, na.rm = T)

    # Calculate Ulcer
    maxValue <- 0
    buff <- equityPerTrade
    for (t in 1:numberOfTrades) {
      if (equityPerTrade[t] > maxValue)
        maxValue <- equityPerTrade[t]
      else
        buff[t] <- maxValue
    }
    ulcerIndex <-
      sqrt(sum(((
        equityPerTrade - buff
      ) / buff * 100) ^ 2) / numberOfTrades)
    ulcerPerformanceIndex <- netPNLP / ulcerIndex

    # Calculate longs-shorts ratio
    longShortRatio <- numberOfLongs / numberOfShorts

    # Calculate average winning trades
    averageWinningTrade <- mean(pnlp[pnlp > 0])

    # Calculate average losing trades
    averageLosingTrade <- -mean(pnlp[pnlp <= 0])

    # Calculate barsConsumed
    barsConsumed <- List.ExitIndex - List.EntryIndex

    # Calculate averageBarsInTrades
    averageBarsInTrades <- mean(barsConsumed)

    # Calculate percentInMarket
    percentInMarket <-
      (sum(barsConsumed) / (List.ExitIndex[length(List.ExitIndex)] - List.EntryIndex[1])) * 100

    # Calculate MaxDrawDown on Balance
    maxDiffList <- NULL
    for (i in 1:(length(equityPerTrade) - 1)) {
      difList <- NULL
      for (j in (i + 1):length(equityPerTrade))
        if (equityPerTrade[i] > equityPerTrade[j])
          difList <-
            c(difList,
              (equityPerTrade[i] - equityPerTrade[j]) / abs(equityPerTrade[i]))
        if (!is.null(difList))
          maxDiffList <- c(maxDiffList, max(difList))
    }

    if (!is.null(maxDiffList))
      maxDrawDown <- 100 * max(maxDiffList)
    else
      maxDrawDown <- NA

    # Calculate MaxUnrealizedLoss and MaxUnrealizedProfit
    maxUnrealizedLoss <-
      as.numeric(matrix(nrow = numberOfTrades, ncol = 1, NA))
    maxUnrealizedProfit <-
      as.numeric(matrix(nrow = numberOfTrades, ncol = 1, NA))
    for (trade in 1:numberOfTrades) {
      if (List.Side[trade] == "Long") {
        if (List.SL.doHit[trade]) {
          maxUnrealizedLoss[trade] <-
            (List.ExitPrice[trade] - List.EntryPrice[trade]) / List.EntryPrice[trade] *
            100 * List.PSM[trade]
          maxUnrealizedProfit[trade] <-
            (max(dataset$High[List.EntryIndex[trade]:List.ExitIndex[trade]]) - List.EntryPrice[trade]) /
            List.EntryPrice[trade] * 100 * List.PSM[trade]
        }
        else
        {
          maxUnrealizedLoss[trade]   <-
            (min(dataset$Low[List.EntryIndex[trade]:(List.ExitIndex[trade] - 1)]) -
               List.EntryPrice[trade]) / List.EntryPrice[trade] * 100 * List.PSM[trade]
          maxUnrealizedProfit[trade] <-
            (max(dataset$High[List.EntryIndex[trade]:(List.ExitIndex[trade] - 1)]) -
               List.EntryPrice[trade]) / List.EntryPrice[trade] * 100 * List.PSM[trade]
        }
      }
      else{
        if (List.SL.doHit[trade]) {
          maxUnrealizedLoss[trade] <-
            (List.EntryPrice[trade] - List.ExitPrice[trade]) / List.EntryPrice[trade] *
            100 * List.PSM[trade]
          maxUnrealizedProfit[trade] <-
            (List.EntryPrice[trade] - min(dataset$Low[List.EntryIndex[trade]:List.ExitIndex[trade]])) /
            List.EntryPrice[trade] * 100 * List.PSM[trade]
        }
        else{
          maxUnrealizedLoss[trade]   <-
            (List.EntryPrice[trade] - max(dataset$High[List.EntryIndex[trade]:(List.ExitIndex[trade] -
                                                                                 1)])) / List.EntryPrice[trade] * 100 * List.PSM[trade]
          maxUnrealizedProfit[trade] <-
            (List.EntryPrice[trade] - min(dataset$Low[List.EntryIndex[trade]:(List.ExitIndex[trade] -
                                                                                1)])) / List.EntryPrice[trade] * 100 * List.PSM[trade]
        }

      }
    }
    maxUnrealizedLoss <- maxUnrealizedLoss - commision * 2 * List.PSM
    maxUnrealizedProfit <-
      maxUnrealizedProfit - commision * 2 * List.PSM
    maxUnrealizedLoss[maxUnrealizedLoss > 0] <- 0
    maxUnrealizedLoss <- -maxUnrealizedLoss
    maxUnrealizedProfit[maxUnrealizedProfit < 0] <- 0

    # Calculate TotalMaxUnrealizedLoss
    totalMaxUnrealizedLoss <- max(maxUnrealizedLoss)

    # Calculate RiskReturnRatio
    riskReturnRatio <- netPNLP / maxDrawDown

    # Calculate Detailed results
    maxDrawDownDetailed <- NA
    equityOCHL <- NA
    if (detailed) {
      # Calculate Unrealized Equity
      Equity.Open  <-
        c(initialCapital, equityPerTrade[1:(numberOfTrades - 1)])
      Equity.Close <- equityPerTrade
      Equity.High  <-
        Equity.Open * maxUnrealizedProfit / 100 + Equity.Open
      Equity.Low   <-
        Equity.Open - (Equity.Open * (-1 * maxUnrealizedLoss) / 100)

      # Calculate MaxDrawDown on Unrealized Equity
      maxDiffList <- NULL
      for (i in 1:(length(equityPerTrade) - 1)) {
        difList <- NULL
        for (j in (i + 1):length(equityPerTrade))
          if (Equity.High[i] > Equity.Low[j])
            difList <-
              c(difList, (Equity.High[i] - Equity.Low[j]) / Equity.High[i])
          if (!is.null(difList))
            maxDiffList <- c(maxDiffList, max(difList))
      }

      if (!is.null(maxDiffList))
        maxDrawDownDetailed <- 100 * max(maxDiffList)
      else
        maxDrawDownDetailed <- NA

      equityOCHL <- list(
        Open = Equity.Open,
        Close = Equity.Close,
        High = Equity.High,
        Low = Equity.Low
      )
    }

    # Generate List of Trades
    trades <-
      list(
        TradeNumber         = 1:numberOfTrades,
        Side                = List.Side,
        PositionSize        = round(List.PSM, digits = 5),
        EntryPrice          = List.EntryPrice,
        EntryIndex          = List.EntryIndex,
        EntryDate           = dataset$Date[List.EntryIndex],
        ExitPrice           = List.ExitPrice,
        ExitIndex           = List.ExitIndex,
        HitStoploss         = List.SL.doHit,
        ExitDate            = dataset$Date[List.ExitIndex],
        BarsConsumed        = barsConsumed,
        MaxUnrealizedLoss   = round(maxUnrealizedLoss, digits = 2),
        MaxUnrealizedProfit = round(maxUnrealizedProfit, digits = 2),
        Equity              = round(equityPerTrade, digits = 2),
        PNL                 = round(pnl, digits = 2),
        PNLP                = round(pnlp, digits = 2)
      )

    # Return the result
    res <-
      list(
        DatasetName            = paste(pairName, strsplit(rev(
          setdiff(strsplit(
            ifelse(is.na(datasetName), "", datasetName), "/|\\\\"
          )[[1]], "")
        )[1], "\\.")[[1]][1], sep = " - "),
        EquityOCHL             = equityOCHL,
        Balance                = balance,
        InitialCapital         = initialCapital,
        NetPNLP                = round(netPNLP, digits = 2),
        NetPNL                 = round(netPNL, digits = 2),
        WinRate                = round(winRate, digits = 2),
        MaxProfit              = round(maxProfit, digits = 2),
        MaxLoss                = round(maxLoss, digits = 2),
        NumberOfShorts         = numberOfShorts,
        NumberOfLongs          = numberOfLongs,
        NumberOfTrades         = numberOfTrades,
        LongShortRatio         = round(longShortRatio, digits = 2),
        AverageBarsInTrades    = round(averageBarsInTrades, digits = 2),
        AverageLosingTrade     = round(averageLosingTrade, digits = 2),
        AverageWinningTrade    = round(averageWinningTrade, digits = 2),
        PercentInMarket        = round(percentInMarket, digits = 2),
        SharpeRatio            = round(sharpeRatio, digits =  2),
        UlcerPerformanceIndex  = round(ulcerPerformanceIndex, digits =  2),
        GrossProfit            = round(grossProfit, digits = 2),
        GrossLoss              = round(grossLoss, digits = 2),
        ProfitFactor           = round(profitFactor, digits = 2),
        BuyAndHold             = round(buyAndHold, digits = 2),
        MaxDrawDown            = round(maxDrawDown, digits = 2),
        MaxDrawDownDetailed    = ifelse(
          !is.na(maxDrawDownDetailed),
          round(maxDrawDownDetailed, digits = 2),
          NA
        ),
        TotalMaxUnrealizedLoss = round(totalMaxUnrealizedLoss, digits = 2),
        AverageMonthlyReturn   = round(averageMonthlyReturn, digits = 2),
        EachMonthReturn        = round(eachMonthReturn, digits = 2),
        RiskReturnRatio        = riskReturnRatio,
        Trades                 = as.data.frame(trades)
      )
    return(res)
  }
