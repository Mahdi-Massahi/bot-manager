#' Transition Function [O(1)]
#'
#' Transition from x to y by following method.
#' Complexity order: O(1)
#' @param x a numerical vector or number
#' @param a a coefficent of the transition function
#' @param type [spindle]
#' @return y as feeding x and a to the function
#' @export

Neb.Transition <- function(x, a, type="spindle")
{
  NAs <- is.na(x)
  x[is.na(x)] <- 0

  if(type == "spindle"){
    x <- round(x, 4)
    if (max(x) > 1 | min(x) < 0 | abs(a) > 0.7)
      warning("input value out of range")
    else{
      c = sqrt(2) / 2
      if (a != 0) {
        buff <-(1/(2*a*c))-x+1-((1/(2*a*c))*sqrt(1+4*a*c-8*a*c*x+2*a*a))
        buff[NAs] <- NA
        return(buff)
      }
      else{
        buff <- x
        buff[NAs] <- NA
        return(buff)
      }
    }
  }
}
