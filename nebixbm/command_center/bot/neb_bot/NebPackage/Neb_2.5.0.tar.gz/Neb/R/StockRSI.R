#' Stockastic Relative Strength Index [O(3n)]
#'
#' Calculates Stockastic Relative Strength Index of a serie with the givven length.
#' Complexity order: O(3n)
#' @param serie a numerical vector
#' @param length an intger number
#' @param smoothD an intger number, default value is 3
#' @param smoothK an intger number, default value is 3
#' @return a StockRSI as vector
#' @seealso
#' \link{Neb.Stock}
#' \link{Neb.RSI}
#' @export

Neb.StockRSI <- function(serie, length, smoothK=3, smoothD=3)
{
  return(Neb.Stock(Neb.RSI(serie, length), length, smoothK, smoothD))
}
