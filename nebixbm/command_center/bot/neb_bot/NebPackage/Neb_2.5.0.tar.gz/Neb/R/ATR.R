#' Average True Range [O(c)]
#'
#' Calculates Average True Range of a candlestick serie with the givven, high, low, close, and length.
#' Complexity order: O(length)
#' @param high a numerical vector of candles' high
#' @param low a numerical vector of candles' low
#' @param close a numerical vector of candles' close
#' @param length [1, +inf]eN an intger number
#' @return an ATR values as vector
#' @seealso
#' \link{Neb.SMA}
#' \link{Neb.TR}
#' @export

Neb.ATR <- function(high, low, close, length)
{
  if(length(high) == length(low))
    if(length(high) == length(close))
      return(Neb.SMA(Neb.TR(high, low, close), length))
  return(warning("ATR input error. All input vectors for high, low, and close must have a same length."))
}
