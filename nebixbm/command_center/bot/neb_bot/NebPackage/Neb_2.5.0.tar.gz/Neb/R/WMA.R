#' Weighted Moving Average [O(n)]
#'
#' Calculates Weighted Moving Avrage of a serie with the givven length.
#' Complexity order: O(n)
#' @param serie a numerical vector
#' @param length an intger number
#' @return a weighted moving average as vector
#' @export

Neb.WMA <- function(serie, length)
{
  wma <- as.numeric(matrix(NA,nrow=1, ncol= length-1))
  for (i in 1:(length(serie)-length+1)) {
    selection = serie[i:(i+length-1)]

    wr = 0
    for (j in 1:length) {
      wr <- wr + selection[j]*j
    }
    wr <- wr/sum(1:length)
    wma <- c(wma, wr)
  }
  return(wma)
}
