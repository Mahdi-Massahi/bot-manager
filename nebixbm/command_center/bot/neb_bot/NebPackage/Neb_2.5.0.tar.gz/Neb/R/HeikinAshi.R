#' HeikinAshi [O(n)]
#'
#' Returns the HeikinAshi form of a candlestick serie with the givven dataset.
#' Complexity order: O(length(data))
#' @param data a candlestick data
#' @return the HeikinAshi data as list
#' @export

Neb.HeikinAshi <- function(data) {
  # Initializing variables
  HA.O <- as.numeric(matrix(NA, ncol = 1, nrow = dim(data)[1]))
  HA.C <- as.numeric(matrix(NA, ncol = 1, nrow = dim(data)[1]))
  HA.H <- as.numeric(matrix(NA, ncol = 1, nrow = dim(data)[1]))
  HA.L <- as.numeric(matrix(NA, ncol = 1, nrow = dim(data)[1]))

  # Initializing first HA values
  HA.O[1] <- (data$Open[1] + data$Close[1]) / 2
  HA.H[1] <- data$High[1]
  HA.L[1] <- data$Low[1]

  # Value calculation
  HA.C <- (data$Open + data$Close + data$High + data$Low) / 4
  for (i in 2:dim(data)[1]) {
    HA.O[i] <- (HA.O[i - 1] + HA.C[i - 1]) / 2
    HA.H[i] <- max(data$High[i], HA.O[i], HA.C[i])
    HA.L[i] <- min(data$Low[i], HA.O[i], HA.C[i])
  }

  # return the res as list
  return(list(
    Open  = HA.O,
    Close = HA.C,
    High  = HA.H,
    Low   = HA.L
  ))
}
