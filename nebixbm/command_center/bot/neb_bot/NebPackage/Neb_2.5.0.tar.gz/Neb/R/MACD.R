#' Moving Average Convergence Divergence [O(c)]
#'
#' Calculates Moving Average Convergence Divergence of a serie with the givven slow and fast lengthes.
#' Complexity order: O(fast + slow)
#' @param serie a numerical vector
#' @param fast an intger number for fast EMA
#' @param slow an intger number for slow EMA
#' @return a MACD as vector
#' @seealso
#' \link{Neb.EMA}
#' @export

Neb.MACD <- function(serie, fast, slow)
{
  if(fast > slow)
  {
    warning("Fast value for MACD is grater than the Slow value, thus they are replaced.")
    buff <- fast
    fast <- slow
    slow <- buff
  }
  FEMA <- Neb.EMA(serie, fast)[slow:length(serie)]
  SEMA <- Neb.EMA(serie, slow)[slow:length(serie)]
  MACD <- matrix(NA, nrow = 1, ncol = length(serie))
  MACD[slow:length(serie)] <- SEMA - FEMA
  return(as.numeric(MACD))
}
