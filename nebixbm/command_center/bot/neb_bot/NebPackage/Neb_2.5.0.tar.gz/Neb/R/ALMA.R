#' Arnaud Legoux Moving Average [O(c)]
#'
#' Calculates ALMA of a serie with the givven sigma, offset, and size.
#' Complexity order: O(size)
#' @param serie a numerical vector
#' @param sigma [-inf, +inf]eR - {0} The sigma is used for the filter.
#' Any value less than 6 makes the indicator more focused,
#' whereas the setting of 6 makes the filter large.
#' According to Mr Arnaud, a sigma value of 6 is offer good performance.
#' @param offset (0, 1)eR The offset value is used to tweak the ALMA so that it will be
#' more inclined towards responsiveness or smoothness. You can set the offset
#' in decimals between the 0 to 1. The value of 0.01 makes it smoother,
#' while a setting of 0.99 makes the indicator more responsive.
#' @param size [1, +inf]eN The window size is the look-back period and it is a basic
#' setting of ALMA. Experienced traders can change this setting according
#' to their preference.
#' @return an ALMA as vector
#' @export

Neb.ALMA <- function(serie, sigma, offset, size)
{
  if(sigma == 0)
    return(warning("ALMA input error. Sigma can not be 0."))
  if(floor(size) <= 0)
    return(warning("ALMA input error. Size can not be 0 or negative."))
  if(offset >= 1 | offset <= 0)
    return(warning("ALMA input error. Offset value must be in range (0, 1)."))
  if(floor(size) == 1)
    return(serie)
  e <- exp(-(((1:size)-offset)^2)/(sigma^2))
  A <- serie*e[1]
  for (k in 1:(size-1)){
    A <- rbind(A, (c(rep(NA, k), serie[1:(length(serie)-k)])*e[k+1]))
  }
  return(apply(A, 2, sum)/sum(e))
}
