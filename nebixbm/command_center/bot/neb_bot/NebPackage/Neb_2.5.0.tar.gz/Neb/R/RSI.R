#' Relative Strength Index [O(2n)]
#'
#' Calculates Relative Strength Index of a serie with the givven length.
#' Complexity order: O(2n)
#' @param serie a numerical vector
#' @param length an intger number
#' @return a RSI as vector
#' @export

Neb.RSI <- function(serie, length)
{
  Change <- c(0,(c(serie[-1],NA) - serie)[-1*length(serie)])
  Gain   <- ifelse(Change>0,Change,0)
  Loss   <- ifelse(Change<0,-1*Change,0)
  AvGain <- as.numeric(matrix(0, nrow = 1, ncol = length))
  AvGain <- c(AvGain,sum(Gain[1:14])/14)
  for (i in (length+2):length(serie)) {
    AvGain[i] <- (AvGain[i-1]*13 + Gain[i])/14
  }
  AvLoss <- as.numeric(matrix(0, nrow = 1, ncol = length))
  AvLoss <- c(AvLoss,sum(Loss[1:14])/14)
  for (i in (length+2):length(serie)) {
    AvLoss[i] <- (AvLoss[i-1]*13 + Loss[i])/14
  }
  RS  <- AvGain/AvLoss
  RSI <- 100 - (100/(1+RS))
  RSI <- as.numeric(gsub(NaN, NA, RSI))
  return(RSI)
}
