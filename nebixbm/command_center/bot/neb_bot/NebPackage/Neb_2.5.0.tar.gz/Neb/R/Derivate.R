#' Derivate [O(1)]
#'
#' Calculates the derivative of the serie.
#' Complexity order: O(1)
#' @param serie a numerical vector
#' @param back [1, +inf]eN an intger number of bars-back, default is 1
#' @return a derivative of the serie as vector
#' @seealso
#' \link{Neb.Previous}
#' @export


Neb.Derivate <- function(serie, back = 1)
{
  return(serie - Neb.Previous(serie, back))
}
