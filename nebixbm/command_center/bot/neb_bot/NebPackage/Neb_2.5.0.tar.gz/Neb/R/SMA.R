#' Simple Moving Average [O(c)]
#'
#' Calculates Simple Moving Avrage of a serie in the givven length.
#' Complexity order: O(length)
#' @param serie a numerical vector
#' @param length [1, +inf]eN an intger number
#' @return a simple moving average as vector
#' @export

Neb.SMA <- function(serie, length)
{
  if(length == 1)
    return(serie)
  sum <- serie
  for (i in 1:(length-1))
  {
    sum <-
      sum + c(matrix(0, nrow=1, ncol=i), serie[1:(length(serie)-i)])
  }
  sum[1:(length-1)] = NA
  return(sum/length)
}
