#' Dynamic Length Apply [O[n]]
#'
#' This function apples Neb. functions
#' #' Complexity order: O(length(serie) + sort(unique(dL))
#' @param func Neb package functions which only require serie and length for inputs
#' @param serie a serie as a vector
#' @param dL dynamic Length as a vector
#' @return a vector as result
#' @export

Neb.DLApply <- function(func, serie, dL){
  if (length(dL) == 1) {
    return(func(serie, dL))
  }
  if (length(serie) != length(dL)) {
    stop("Error in Neb.DLApply. Input serie and dL vector must have a the same length.")
  }
  Ls  <- sort(unique(floor(dL)), decreasing = T)
  res <- as.numeric(matrix(ncol = 1, nrow = length(serie), NA))
  for (L in Ls)
    res[dL == L] <- func(serie, L)[dL == L]
  return(res)
}
