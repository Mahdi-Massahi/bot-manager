#' True Range [O(1)]
#'
#' Calculates True Range of a candlestick serie with the givven, high, low, and close.
#' Complexity order: O(1)
#' @param high a numerical vector of candles' high
#' @param low a numerical vector of candles' low
#' @param close a numerical vector of candles' close
#' @return an true range values as vector
#' @seealso
#' \link{Neb.Previous}
#' @export

Neb.TR <- function(high, low, close)
{
  if(length(high) == length(low))
    if(length(high) == length(close))
      pc  <- Neb.Previous(close, 1)
      mat <- matrix(nrow = length(pc), ncol = 3, NA)
      mat[, 1] <- high - low
      mat[, 2] <- abs(high - pc)
      mat[, 3] <- abs(low - pc)
      return(apply(mat, 1, max))
  return(warning("TR input error. All input vectors for high, low, and close must have a same length."))
}
