#' Stock [O(n)]
#'
#' Calculates Stock of a serie with the givven length.
#' Complexity order: O(n)
#' @param serie a numerical vector
#' @param length an intger number
#' @param smoothD an intger number, default value is 3
#' @param smoothK an intger number, default value is 3
#' @return a stock as vector
#' @seealso
#' \link{Neb.EMA}
#' @export

Neb.Stock <- function(serie, length, smoothD = 3, smoothK=3)
{
  mins <- as.numeric(matrix(NA, ncol=length-1))
  maxs <- as.numeric(matrix(NA, ncol=length-1))

  for (i in length:length(serie) ) {
    mins <- c(mins, min(serie[(i-length+1):i]))
    maxs <- c(maxs, max(serie[(i-length+1):i]))
  }

  K = Neb.SMA(100*(serie-mins)/(maxs-mins), smoothK)
  D = Neb.SMA(K, smoothD)
  return(cbind(K, D))
}
