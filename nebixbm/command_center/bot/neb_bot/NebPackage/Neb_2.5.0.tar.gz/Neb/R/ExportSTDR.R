#' Export STD result
#'
#' Exports the result of strategy tester as PDF or HTML.
#' @param SR the result of Neb.ST or a list of it must have STD, Data
#' @param Description a brief text about strategy
#' @param SaveDir the directory of exported file
#' @param type export type [PDF, HTML] default is PDF
#' @param cumulative a boolean option if result is cumulative or not
#' @return PDF or HTML file
#' @export

Neb.ExportSTDR <-
  function(SR,
           Description,
           SaveDir,
           type = "PDF",
           cumulative = F) {
    if (type == "PDF") {
      if (cumulative == F) {
        # Detailed result
        rmarkdown::render(
          system.file("rmd",
                      "STD_Result_PDF.Rmd",
                      package = "Neb"),
          params = list(
            STD  = SR$STD,
            Data = SR$Data,
            Vals = SR$Vals,
            Des  = Description
          ),
          output_dir = SaveDir
        )
      }
      else{
      # Detailed result
        # Detailed result
        rmarkdown::render(
          system.file("rmd",
                      "STDs_Result_PDF.Rmd",
                      package = "Neb"),
          params = list(
            SR   = SR,
            Des  = Description
          ),
          output_dir = SaveDir
        )
      }
    }
  }
