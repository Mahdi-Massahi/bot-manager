#' Efficiency Ratio [O(c)]
#'
#' Calculates efficiency ratio of a serie with the givven length.
#' Complexity order: O(length)
#' @param serie a numerical vector
#' @param length [3, +inf]eN an intger number, must be greater than 2
#' @return an efficiency ratio average as vector
#' @examples
#' Neb.ER <- function(serie, length)
#' {
#'   if(length < 3)
#'     return(warning("ER input error. ER length must be greater than 2."))
#'   dists   <- abs(serie-Neb.Previous(serie, 1))
#'   sums    <- dists
#'   for (i in 2:(length-1)) {
#'     dists <- Neb.Previous(dists, 1)
#'     sums  <- dists + sums
#'   }
#'   net <- abs(serie-Neb.Previous(serie, length-1))
#'   return((net/sums)*100)
#' }
#' @seealso
#' \link{Neb.Previous}
#' @export

Neb.ER <- function(serie, length)
{
  if(length < 3)
    return(warning("ER input error. ER length must be greater than 2."))
  dists   <- abs(serie-Neb.Previous(serie, 1))
  sums    <- dists
  for (i in 2:(length-1)) {
    dists <- Neb.Previous(dists, 1)
    sums  <- dists + sums
  }
  net <- abs(serie-Neb.Previous(serie, length-1))
  return((net/sums)*100)
}
