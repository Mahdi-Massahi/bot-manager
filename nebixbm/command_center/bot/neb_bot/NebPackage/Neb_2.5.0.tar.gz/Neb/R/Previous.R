#' Previous [O(1)]
#'
#' Returns the n bars back as a vector, where n = bars.
#' Complexity order: O(1)
#' @param serie a numerical vector
#' @param bars [1, +inf]eN an intger number
#' @return bars back as vector
#' @export

Neb.Previous <- function(serie, bars)
{
  return(c(rep(NA, bars), serie[1:(length(serie)-bars)]))
}
