#' Lowests In Serie [O(c)]
#'
#' Calculates lowests of a serie with the givven length.
#' Complexity order: O(length)
#' @param serie a numerical vector
#' @param length [1, +inf]eN an intger number
#' @return lowests in serie as vector
#' @export

Neb.LIS <- function(serie, length)
{
  if(length == 1)
    return(serie)
  m <- matrix(NA, nrow = length, ncol=length(serie))
  m[1, ] <- serie
  for (i in 2:length) {
    m[i, ] <- c(matrix(NA, nrow=1, ncol=i-1), serie[1:(length(serie)-(i-1))])
  }
  return(apply(m, 2, FUN=min))
}
