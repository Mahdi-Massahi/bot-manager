#' Exterma [O(1)]
#'
#' Finds exterma of the serie.
#' Complexity order: O(1)
#' @param serie a numerical vector
#' @return a boolean exterma vector
#' @seealso
#' \link{Neb.Derivate}
#' @export

Neb.Exterma <- function(serie)
{
  d <- Neb.Derivate(serie)
  return(ifelse(c(d[2:(length(d))] * d[1:(length(d)-1)], 0) < 0 ,T ,F))
}
